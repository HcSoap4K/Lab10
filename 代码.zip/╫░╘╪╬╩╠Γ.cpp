﻿#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
int a[N], b[N], w[N];
int n, sum, c1, c2, total;

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int cnt = 1;
    scanf("%d%d%d", &n, &c1, &c2);
    for (int i = 1; i <= n; i++) {
        scanf("%d", &w[i]);
        total += w[i];
    }

    sort(w + 1, w + 1 + n);

    for (int i = 1; i <= n; i++) {
        if (sum + w[i] <= c1) {
            a[cnt++] = w[i];
            sum += w[i];
        }
    }

    if (total - sum > c2) {
        puts("无解");
    } else {
        printf("A:");
        for (int i = 1; i < cnt; i++)
            printf("%d ", a[i]);
        puts("");
        printf("B:");
        for (int i = cnt; i <= n; i++)
            printf("%d%c", w[i], " \n"[i == n]);
    }
    return 0;
}
